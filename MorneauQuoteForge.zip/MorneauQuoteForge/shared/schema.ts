import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const quotes = pgTable("quotes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  quoteNumber: text("quote_number").notNull().unique(),
  company: text("company").notNull(),
  originAddress: text("origin_address").notNull(),
  destinationAddress: text("destination_address").notNull(),
  pallets: integer("pallets").notNull(),
  weight: real("weight").notNull(),
  weightUnit: text("weight_unit").notNull(),
  distance: real("distance"),
  fuelType: text("fuel_type").notNull(),
  baseCost: real("base_cost").notNull(),
  weightSurcharge: real("weight_surcharge").notNull().default(0),
  fuelSurcharge: real("fuel_surcharge").notNull(),
  subtotal: real("subtotal").notNull(),
  gst: real("gst").notNull(),
  qst: real("qst").notNull(),
  total: real("total").notNull(),
  issueDate: timestamp("issue_date").notNull().defaultNow(),
  expiryDate: timestamp("expiry_date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const quoteCounter = pgTable("quote_counter", {
  id: varchar("id").primaryKey().default('quote_counter'),
  counter: integer("counter").notNull().default(1),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertQuoteSchema = createInsertSchema(quotes).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertQuote = z.infer<typeof insertQuoteSchema>;
export type Quote = typeof quotes.$inferSelect;
