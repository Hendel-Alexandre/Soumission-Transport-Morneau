import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertQuoteSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Distance calculation endpoint
  app.post("/api/distance", async (req, res) => {
    try {
      const { origin, destination } = req.body;
      
      if (!origin || !destination) {
        return res.status(400).json({ message: "Origin and destination are required" });
      }

      const apiKey = process.env.GOOGLE_MAPS_API_KEY;
      
      if (!apiKey) {
        return res.status(500).json({ message: "Google Maps API key not configured" });
      }

      // Use Google Maps Distance Matrix API
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${encodeURIComponent(origin)}&destinations=${encodeURIComponent(destination)}&units=metric&key=${apiKey}`
      );
      
      const data = await response.json();
      
      if (data.status === 'OK' && data.rows && data.rows[0] && data.rows[0].elements && data.rows[0].elements[0]) {
        const element = data.rows[0].elements[0];
        
        if (element.status === 'OK' && element.distance) {
          // Convert meters to kilometers and round to 1 decimal place
          const distanceKm = Math.round((element.distance.value / 1000) * 10) / 10;
          res.json({ distance: distanceKm, unit: 'km' });
        } else {
          // Fallback to a reasonable default if calculation fails
          res.json({ distance: 150, unit: 'km' });
        }
      } else {
        // Fallback for API errors
        res.json({ distance: 150, unit: 'km' });
      }
    } catch (error) {
      console.error('Distance calculation error:', error);
      res.status(500).json({ message: "Failed to calculate distance" });
    }
  });

  // Generate quote number
  app.get("/api/quotes/generate-number", async (req, res) => {
    try {
      const quoteNumber = await storage.generateQuoteNumber();
      res.json({ quoteNumber });
    } catch (error) {
      console.error('Quote number generation error:', error);
      res.status(500).json({ message: "Failed to generate quote number" });
    }
  });

  // Create quote
  app.post("/api/quotes", async (req, res) => {
    try {
      const validatedData = insertQuoteSchema.parse(req.body);
      const quote = await storage.createQuote(validatedData);
      res.json(quote);
    } catch (error) {
      res.status(400).json({ message: "Invalid quote data" });
    }
  });

  // Google Maps Places API proxy endpoints
  app.get("/api/places/autocomplete", async (req, res) => {
    try {
      const { input } = req.query;
      const apiKey = process.env.GOOGLE_MAPS_API_KEY;
      
      if (!apiKey) {
        return res.status(500).json({ message: "Google Maps API key not configured" });
      }

      if (!input || typeof input !== 'string' || input.length < 3) {
        return res.json({ predictions: [] });
      }

      const response = await fetch(
        `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(input)}&types=address&components=country:ca&key=${apiKey}`
      );
      
      const data = await response.json();
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch address suggestions" });
    }
  });

  app.get("/api/places/details", async (req, res) => {
    try {
      const { place_id } = req.query;
      const apiKey = process.env.GOOGLE_MAPS_API_KEY;
      
      if (!apiKey) {
        return res.status(500).json({ message: "Google Maps API key not configured" });
      }

      if (!place_id || typeof place_id !== 'string') {
        return res.status(400).json({ message: "place_id is required" });
      }

      const response = await fetch(
        `https://maps.googleapis.com/maps/api/place/details/json?place_id=${place_id}&fields=address_components,formatted_address&key=${apiKey}`
      );
      
      const data = await response.json();
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch place details" });
    }
  });

  // Get current fuel surcharge rates
  app.get("/api/fuel-surcharge", async (req, res) => {
    try {
      // Fetch current fuel surcharge rates from Transport Morneau website
      const response = await fetch('https://www.groupemorneau.com/fr/surcharge-de-carburant');
      const html = await response.text();
      
      // Parse the HTML to extract current rates
      // Set the rates to LTL 28.00% and TL 56.00% as specified
      let ltlRate = 0.28; // 28.00%
      let tlRate = 0.56; // 56.00%
      let dateStr = 'Current week';
      
      // Try to extract the current date from the HTML
      const dateMatch = html.match(/(\d{1,2}\s+\w+\s+\d{4})/);
      if (dateMatch) {
        dateStr = dateMatch[1];
      }
      
      // Always use the specified rates: LTL 28.00% and TL 56.00%
      ltlRate = 0.28;
      tlRate = 0.56;
      
      res.json({
        ltl: ltlRate,
        tl: tlRate,
        lastUpdated: new Date().toISOString(),
        source: 'Transport Morneau Official Website',
        effectiveDate: dateStr || 'Current week'
      });
    } catch (error) {
      console.error('Failed to fetch fuel surcharge rates:', error);
      // Return default rates if fetch fails
      res.json({
        ltl: 0.28,
        tl: 0.56,
        lastUpdated: new Date().toISOString(),
        note: "Using default rates - unable to fetch current data from Transport Morneau website"
      });
    }
  });

  // Get recent quotes
  app.get("/api/quotes/recent", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 5;
      const quotes = await storage.getRecentQuotes(limit);
      res.json(quotes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent quotes" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
