import { type User, type InsertUser, type Quote, type InsertQuote, users, quotes, quoteCounter } from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getQuote(id: string): Promise<Quote | undefined>;
  getQuotesByUser(userId: string): Promise<Quote[]>;
  createQuote(quote: InsertQuote): Promise<Quote>;
  getRecentQuotes(limit?: number): Promise<Quote[]>;
  generateQuoteNumber(): Promise<string>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private quotes: Map<string, Quote>;
  private quoteCounter: number = 1000000;

  constructor() {
    this.users = new Map();
    this.quotes = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getQuote(id: string): Promise<Quote | undefined> {
    return this.quotes.get(id);
  }

  async getQuotesByUser(userId: string): Promise<Quote[]> {
    return Array.from(this.quotes.values());
  }

  async createQuote(insertQuote: InsertQuote): Promise<Quote> {
    const id = randomUUID();
    const quote: Quote = { 
      ...insertQuote,
      id,
      distance: insertQuote.distance ?? null,
      weightSurcharge: insertQuote.weightSurcharge ?? 0,
      issueDate: insertQuote.issueDate || new Date(),
      expiryDate: insertQuote.expiryDate || new Date(),
      createdAt: new Date()
    };
    this.quotes.set(id, quote);
    return quote;
  }

  async getRecentQuotes(limit: number = 10): Promise<Quote[]> {
    return Array.from(this.quotes.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async generateQuoteNumber(): Promise<string> {
    this.quoteCounter++;
    return `Q${this.quoteCounter.toString().padStart(7, '0')}`;
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getQuote(id: string): Promise<Quote | undefined> {
    const [quote] = await db.select().from(quotes).where(eq(quotes.id, id));
    return quote || undefined;
  }

  async getQuotesByUser(userId: string): Promise<Quote[]> {
    return await db.select().from(quotes).orderBy(desc(quotes.createdAt));
  }

  async createQuote(insertQuote: InsertQuote): Promise<Quote> {
    const [quote] = await db
      .insert(quotes)
      .values(insertQuote)
      .returning();
    return quote;
  }

  async getRecentQuotes(limit: number = 10): Promise<Quote[]> {
    return await db
      .select()
      .from(quotes)
      .orderBy(desc(quotes.createdAt))
      .limit(limit);
  }

  async generateQuoteNumber(): Promise<string> {
    try {
      // Try to increment the counter
      const result = await db
        .update(quoteCounter)
        .set({ counter: sql`counter + 1` })
        .where(eq(quoteCounter.id, 'quote_counter'))
        .returning({ counter: quoteCounter.counter });

      if (result.length > 0) {
        return `Q${result[0].counter.toString().padStart(7, '0')}`;
      }

      // If no row exists, insert the initial counter
      const insertResult = await db
        .insert(quoteCounter)
        .values({ id: 'quote_counter', counter: 1 })
        .returning({ counter: quoteCounter.counter });

      return `Q${insertResult[0].counter.toString().padStart(7, '0')}`;
    } catch (error) {
      // If insert fails due to unique constraint, try update again
      const result = await db
        .update(quoteCounter)
        .set({ counter: sql`counter + 1` })
        .where(eq(quoteCounter.id, 'quote_counter'))
        .returning({ counter: quoteCounter.counter });

      return `Q${result[0].counter.toString().padStart(7, '0')}`;
    }
  }
}

export const storage = new DatabaseStorage();
