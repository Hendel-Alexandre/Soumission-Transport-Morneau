import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useTheme } from "@/hooks/use-theme";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { calculateDistance, formatAddress } from "@/lib/distance-calculator";
import { generatePDFContent, downloadPDF, type QuoteData } from "@/lib/pdf-generator";
import { Moon, Sun, Truck, Calculator, FileText, Printer, Check, ChevronsUpDown, Phone, Globe, Mail } from "lucide-react";
import logoPath from "@assets/Capture_d_écran_2025-07-25_113507-removebg-preview_1753470021455.png";
import { AddressAutocomplete } from "@/components/address-autocomplete";

interface Quote {
  id: string;
  quoteNumber: string;
  company: string;
  total: number;
  createdAt: string;
}

export default function QuoteGenerator() {
  const { theme, setTheme } = useTheme();
  const { language, setLanguage, t } = useLanguage();
  const { toast } = useToast();

  // Form state
  const [formData, setFormData] = useState({
    company: "",
    originStreet: "",
    originCity: "",
    originProvince: "",
    originPostalCode: "",
    destinationStreet: "",
    destinationCity: "",
    destinationProvince: "",
    destinationPostalCode: "",
    pallets: "",
    weight: "",
    weightUnit: "lb",
    distance: "",
    length: "",
    width: "",
    height: "",
  });

  // Calculation state
  const [quoteData, setQuoteData] = useState<QuoteData | null>(null);
  const [showPDFPreview, setShowPDFPreview] = useState(false);
  const [companyDropdownOpen, setCompanyDropdownOpen] = useState(false);
  const [showManualCompanyInput, setShowManualCompanyInput] = useState(false);

  // Quote number state - only generate when needed
  const [currentQuoteNumber, setCurrentQuoteNumber] = useState<string | null>(null);

  // Get recent quotes
  const { data: recentQuotes = [] } = useQuery<Quote[]>({
    queryKey: ['/api/quotes/recent'],
  });

  // Get current fuel surcharge rates
  const { data: fuelRates } = useQuery<{
    ltl: number;
    tl: number;
    lastUpdated: string;
    note?: string;
    source?: string;
    effectiveDate?: string;
  }>({
    queryKey: ['/api/fuel-surcharge'],
    staleTime: 1000 * 60 * 60, // Cache for 1 hour
  });

  // Create quote mutation
  const createQuoteMutation = useMutation({
    mutationFn: async (quoteData: QuoteData) => {
      const response = await apiRequest('POST', '/api/quotes', {
        quoteNumber: quoteData.quoteNumber,
        company: quoteData.company,
        originAddress: quoteData.originAddress,
        destinationAddress: quoteData.destinationAddress,
        pallets: quoteData.pallets,
        weight: quoteData.weight,
        weightUnit: quoteData.weightUnit,
        distance: quoteData.distance,
        fuelType: quoteData.fuelType,
        baseCost: quoteData.baseCost,
        weightSurcharge: quoteData.weightSurcharge,
        fuelSurcharge: quoteData.fuelSurcharge,
        subtotal: quoteData.subtotal,
        gst: quoteData.gst,
        qst: quoteData.qst,
        total: quoteData.total,
        issueDate: new Date(quoteData.issueDate),
        expiryDate: new Date(quoteData.expiryDate),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/quotes/recent'] });
      // Reset quote number so next quote gets a new number
      setCurrentQuoteNumber(null);
      toast({
        title: t("Quote saved"),
        description: t("Your quote has been saved successfully."),
      });
    },
  });

  // Calculate distance when addresses change
  useEffect(() => {
    if (formData.originCity && formData.destinationCity && formData.originProvince && formData.destinationProvince) {
      const origin = formatAddress(
        formData.originStreet, 
        `${formData.originCity}, ${formData.originProvince}, ${formData.originPostalCode}`
      );
      const destination = formatAddress(
        formData.destinationStreet, 
        `${formData.destinationCity}, ${formData.destinationProvince}, ${formData.destinationPostalCode}`
      );
      
      calculateDistance(origin, destination).then((result) => {
        setFormData(prev => ({ ...prev, distance: result.distance.toString() }));
      });
    }
  }, [formData.originCity, formData.destinationCity, formData.originProvince, formData.destinationProvince, formData.originPostalCode, formData.destinationPostalCode]);

  const calculateQuote = async () => {
    const pallets = parseInt(formData.pallets) || 0;
    const weight = parseFloat(formData.weight) || 0;
    const distance = parseFloat(formData.distance) || 0;

    if (pallets === 0) {
      toast({
        title: t("Error"),
        description: t("Please enter number of pallets"),
        variant: "destructive",
      });
      return;
    }



    if (!formData.company) {
      toast({
        title: t("Error"),
        description: t("Please select a company"),
        variant: "destructive",
      });
      return;
    }

    // Convert weight to pounds if necessary
    const weightInPounds = formData.weightUnit === "kg" ? weight * 2.20462 : weight;

    // Auto-determine TL vs LTL classification based on weight
    // LTL: Under 10,000 lbs, TL: 10,000 lbs and over
    const shipmentType = weightInPounds >= 10000 ? "tl" : "ltl";
    
    // Step 1: Base Rate Total
    // For TL (10,000+ lbs): Use TL base rates
    // For LTL (<10,000 lbs): Use LTL rate per pallet ($69.33)
    let baseCost = 0;
    if (shipmentType === "tl") {
      // TL base rates - you may need to define specific TL rates
      // For now using a base TL rate structure
      baseCost = pallets * 69.33; // This should be updated with actual TL rates
    } else {
      // LTL rate per pallet
      const ratePerPallet = 69.33;
      baseCost = pallets * ratePerPallet;
    }

    // Step 2: Excess Weight Charge (if applicable)
    // excess_charge = qty * excess_charge_per_pallet (if weight > 3900 lb)
    let weightSurcharge = 0;
    if (weightInPounds > 3900) {
      const excessChargePerPallet = 0.20;
      weightSurcharge = pallets * excessChargePerPallet;
    }

    // Step 3: Fuel Surcharge
    // fuel_surcharge = fuel_rate * base_rate (based on auto-determined shipment type)
    const fuelRate = fuelRates 
      ? (shipmentType === "ltl" ? fuelRates.ltl : fuelRates.tl)
      : (shipmentType === "ltl" ? 0.28 : 0.56);
    const fuelSurcharge = baseCost * fuelRate;

    // Step 4: Subtotal
    // subtotal = base_rate + excess_charge + fuel_surcharge
    const subtotal = baseCost + weightSurcharge + fuelSurcharge;

    // Step 5: Taxes for Quebec
    // gst = subtotal * 0.05
    // qst = subtotal * 0.09975
    const gst = subtotal * 0.05;
    const qst = subtotal * 0.09975;
    
    // Step 6: Final Total
    // total = subtotal + gst + qst
    const total = subtotal + gst + qst;

    // Dates
    const issueDate = new Date();
    const expiryDate = new Date();
    expiryDate.setDate(issueDate.getDate() + 30);

    // Generate quote number if we don't have one yet
    if (!currentQuoteNumber) {
      try {
        const response = await fetch('/api/quotes/generate-number');
        const data = await response.json();
        setCurrentQuoteNumber(data.quoteNumber);
      } catch (error) {
        console.error('Failed to generate quote number:', error);
        setCurrentQuoteNumber(`Q${Date.now()}`);
      }
    }

    const newQuoteData: QuoteData = {
      quoteNumber: currentQuoteNumber || `Q${Date.now()}`,
      company: formData.company,
      originAddress: formatAddress(
        formData.originStreet, 
        `${formData.originCity}, ${formData.originProvince}, ${formData.originPostalCode}`
      ),
      destinationAddress: formatAddress(
        formData.destinationStreet, 
        `${formData.destinationCity}, ${formData.destinationProvince}, ${formData.destinationPostalCode}`
      ),
      pallets,
      weight: weightInPounds,
      weightUnit: formData.weightUnit,
      distance,
      fuelType: shipmentType,
      baseCost,
      weightSurcharge,
      fuelSurcharge,
      subtotal,
      gst,
      qst,
      total,
      issueDate: issueDate.toISOString().split('T')[0],
      expiryDate: expiryDate.toISOString().split('T')[0],
      dimensions: formData.length || formData.width || formData.height ? {
        length: formData.length || '',
        width: formData.width || '',
        height: formData.height || '',
      } : undefined,
    };

    setQuoteData(newQuoteData);
  };

  const handleGeneratePDF = () => {
    if (!quoteData) return;
    setShowPDFPreview(true);
  };

  const handleDownloadPDF = async () => {
    if (!quoteData) return;
    await downloadPDF(quoteData, language);
    setShowPDFPreview(false);
  };

  const handlePrint = () => {
    if (!quoteData) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    
    const content = generatePDFContent(quoteData, language);
    printWindow.document.write(`
      <html>
        <head>
          <title>${t("Transportation Quote")} - Transport Morneau</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            @media print { .no-print { display: none; } }
          </style>
        </head>
        <body>
          ${content}
          <div class="no-print" style="margin-top: 20px; text-align: center;">
            <button onclick="window.print()" style="margin-right: 10px; padding: 10px 20px;">${t("Print")}</button>
            <button onclick="window.close()" style="padding: 10px 20px;">${t("Close")}</button>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleSaveQuote = () => {
    if (!quoteData) return;
    createQuoteMutation.mutate(quoteData);
  };

  const companies = [
    "Agri-Flex",
    "Agri-Marché Inc.",
    "Agritex Group",
    "Agropur Cooperative",
    "AgroEnviroLab",
    "AquaVerti Farms",
    "Bio Agri Mix LP",
    "BSA Wiberg Inc.",
    "CarbonBook",
    "CIAQ",
    "Commensal",
    "Congebec Logistics",
    "Dispersa",
    "Dominion & Grimm Inc",
    "Entosystem",
    "Erablière Turkey Hill Limitée",
    "Exceldor Cooperative",
    "Fertilec Ltd",
    "Ferti Technologies Inc.",
    "Ferme St-Ours Inc.",
    "Fontaine Santé Foods Inc.",
    "Genuine Taste",
    "Goodfood Market",
    "Groupe Anderson inc.",
    "Harvest Moon Foods",
    "IRDA",
    "J.G. Rive-Sud Fruits & Légumes Inc.",
    "KSM",
    "La Coopérative des horticulteurs de Québec",
    "La Coop Fédérée",
    "La Meunerie Milanaise",
    "Lantic Maple Inc.",
    "Lassonde Industries Inc.",
    "Les Aliments BCI Inc.",
    "Les Industries Bernard & Fils Ltée",
    "Les Terres Fortin Daigle inc.",
    "Lufa Farms",
    "Norseco Inc.",
    "Nutrinor Cooperative",
    "Olymel",
    "Produits d'Érable Prestige Inc.",
    "Prograin",
    "Rovibec Agrisolutions",
    "Saputo Inc.",
    "Semican",
    "SIGA",
    "Sogelco International Inc.",
    "Synagri",
    "Valmetal Group",
    "Vertdure"
  ].sort();

  const canadianProvinces = [
    { code: "AB", name: "Alberta" },
    { code: "BC", name: "British Columbia" },
    { code: "MB", name: "Manitoba" },
    { code: "NB", name: "New Brunswick" },
    { code: "NL", name: "Newfoundland and Labrador" },
    { code: "NS", name: "Nova Scotia" },
    { code: "NT", name: "Northwest Territories" },
    { code: "NU", name: "Nunavut" },
    { code: "ON", name: "Ontario" },
    { code: "PE", name: "Prince Edward Island" },
    { code: "QC", name: "Quebec" },
    { code: "SK", name: "Saskatchewan" },
    { code: "YT", name: "Yukon" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Mobile Layout - Centered logo with language left, dark mode right */}
          <div className="flex sm:hidden justify-between items-center py-3">
            {/* Language Toggle - Left */}
            <div className="flex items-center space-x-1">
              <Button
                variant={language === "fr" ? "default" : "ghost"}
                size="sm"
                onClick={() => setLanguage("fr")}
                className="text-xs h-8 w-8 p-1"
              >
                FR
              </Button>
              <Button
                variant={language === "en" ? "default" : "ghost"}
                size="sm"
                onClick={() => setLanguage("en")}
                className="text-xs h-8 w-8 p-1"
              >
                EN
              </Button>
            </div>

            {/* Centered Logo */}
            <div className="flex-1 flex justify-center">
              <a 
                href="https://www.groupemorneau.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="cursor-pointer hover:opacity-80 transition-opacity block"
              >
                <img 
                  src={logoPath} 
                  alt="Transport Morneau Logo" 
                  className={`h-10 w-auto object-contain transition-all duration-300 ${
                    theme === 'dark' ? 'logo-dark-mode' : ''
                  }`}
                />
              </a>
            </div>

            {/* Dark Mode Toggle - Right */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              className="h-8 w-8 p-1"
            >
              <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            </Button>
          </div>

          {/* Desktop Layout - Original design */}
          <div className="hidden sm:flex justify-between items-center py-4">
            {/* Logo - Fixed size and aspect ratio */}
            <div className="flex items-center flex-shrink-0">
              <a 
                href="https://www.groupemorneau.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="cursor-pointer hover:opacity-80 transition-opacity block"
              >
                <img 
                  src={logoPath} 
                  alt="Transport Morneau Logo" 
                  className={`h-12 lg:h-14 w-auto object-contain transition-all duration-300 ${
                    theme === 'dark' ? 'logo-dark-mode' : ''
                  }`}
                />
              </a>
            </div>
            
            {/* Center title - responsive */}
            <div className="flex-1 flex justify-center mx-4">
              <div className="text-center">
                <h1 className="text-xl lg:text-2xl font-bold text-gray-900 dark:text-white">
                  SOUMISSIONS
                </h1>
                {(currentQuoteNumber || quoteData?.quoteNumber) ? (
                  <div className="bg-[#0884ac] text-white px-4 py-1 rounded-md text-sm font-bold mt-2 inline-block">
                    {t("Quote #")} {quoteData?.quoteNumber || currentQuoteNumber}
                  </div>
                ) : (
                  <div className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                    {t("Quote #")} ---
                  </div>
                )}
              </div>
            </div>

            {/* Controls - responsive */}
            <div className="flex items-center space-x-4 flex-shrink-0">
              {/* Language Toggle */}
              <div className="flex items-center space-x-2">
                <Button
                  variant={language === "fr" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setLanguage("fr")}
                  className="text-xs h-9 w-12 px-2"
                >
                  FR
                </Button>
                <Button
                  variant={language === "en" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setLanguage("en")}
                  className="text-xs h-9 w-12 px-2"
                >
                  EN
                </Button>
              </div>

              {/* Theme Toggle */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setTheme(theme === "light" ? "dark" : "light")}
                className="h-9 w-9 p-1"
              >
                <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quote Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                    {t("New Quote")}
                  </h2>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    {t("Quote #")} {quoteData?.quoteNumber || currentQuoteNumber || "---"}
                  </div>
                </div>

                <div className="space-y-6">
                  {/* Company Selection */}
                  <div>
                    <Label>{t("Company")}</Label>
                    {showManualCompanyInput ? (
                      <div className="space-y-2">
                        <Input
                          placeholder={t("Enter your company name...")}
                          value={formData.company}
                          onChange={(e) => setFormData(prev => ({ ...prev, company: e.target.value }))}
                        />
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setShowManualCompanyInput(false);
                            setFormData(prev => ({ ...prev, company: "" }));
                          }}
                          className="text-xs text-gray-500 hover:text-gray-700"
                        >
                          ← {t("Back to company list")}
                        </Button>
                      </div>
                    ) : (
                      <Popover open={companyDropdownOpen} onOpenChange={setCompanyDropdownOpen}>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={companyDropdownOpen}
                            className="w-full justify-between"
                          >
                            {formData.company
                              ? t(companies.find((company) => company === formData.company) || formData.company)
                              : t("Select a company...")}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0">
                          <Command>
                            <CommandInput placeholder={t("Search companies...")} />
                            <CommandEmpty>{t("No company found.")}</CommandEmpty>
                            <CommandList>
                              <CommandGroup>
                                {companies.map((company) => (
                                  <CommandItem
                                    key={company}
                                    value={company}
                                    onSelect={(currentValue) => {
                                      setFormData(prev => ({ 
                                        ...prev, 
                                        company: currentValue === formData.company ? "" : currentValue 
                                      }));
                                      setCompanyDropdownOpen(false);
                                    }}
                                  >
                                    <Check
                                      className={`mr-2 h-4 w-4 ${
                                        formData.company === company ? "opacity-100" : "opacity-0"
                                      }`}
                                    />
                                    {t(company)}
                                  </CommandItem>
                                ))}
                                
                                {/* Manual Input Option */}
                                <CommandItem
                                  onSelect={() => {
                                    setShowManualCompanyInput(true);
                                    setCompanyDropdownOpen(false);
                                  }}
                                  className="border-t border-gray-200 dark:border-gray-700 text-transport-blue"
                                >
                                  <span className="mr-2">✏️</span>
                                  {t("Can't find your company?")}
                                </CommandItem>
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                    )}
                  </div>

                  {/* Addresses */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label>{t("Origin Address (Shipper)")}</Label>
                      <div className="space-y-3">
                        <AddressAutocomplete
                          placeholder={t("Start typing address...")}
                          value={formData.originStreet}
                          onChange={(value) => setFormData(prev => ({ ...prev, originStreet: value }))}
                          onAddressSelect={(address) => setFormData(prev => ({
                            ...prev,
                            originStreet: address.street,
                            originCity: address.city,
                            originProvince: address.province,
                            originPostalCode: address.postalCode
                          }))}
                        />
                        <Input
                          placeholder={t("City")}
                          value={formData.originCity}
                          onChange={(e) => setFormData(prev => ({ ...prev, originCity: e.target.value }))}
                        />
                        <Select value={formData.originProvince} onValueChange={(value) => 
                          setFormData(prev => ({ ...prev, originProvince: value }))
                        }>
                          <SelectTrigger>
                            <SelectValue placeholder={t("Province")} />
                          </SelectTrigger>
                          <SelectContent>
                            {canadianProvinces.map((province) => (
                              <SelectItem key={province.code} value={province.code}>
                                {t(province.name)} ({province.code})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          placeholder={t("Postal Code")}
                          value={formData.originPostalCode}
                          onChange={(e) => setFormData(prev => ({ ...prev, originPostalCode: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div>
                      <Label>{t("Destination Address (Consignee)")}</Label>
                      <div className="space-y-3">
                        <AddressAutocomplete
                          placeholder={t("Start typing address...")}
                          value={formData.destinationStreet}
                          onChange={(value) => setFormData(prev => ({ ...prev, destinationStreet: value }))}
                          onAddressSelect={(address) => setFormData(prev => ({
                            ...prev,
                            destinationStreet: address.street,
                            destinationCity: address.city,
                            destinationProvince: address.province,
                            destinationPostalCode: address.postalCode
                          }))}
                        />
                        <Input
                          placeholder={t("City")}
                          value={formData.destinationCity}
                          onChange={(e) => setFormData(prev => ({ ...prev, destinationCity: e.target.value }))}
                        />
                        <Select value={formData.destinationProvince} onValueChange={(value) => 
                          setFormData(prev => ({ ...prev, destinationProvince: value }))
                        }>
                          <SelectTrigger>
                            <SelectValue placeholder={t("Province")} />
                          </SelectTrigger>
                          <SelectContent>
                            {canadianProvinces.map((province) => (
                              <SelectItem key={province.code} value={province.code}>
                                {t(province.name)} ({province.code})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          placeholder={t("Postal Code")}
                          value={formData.destinationPostalCode}
                          onChange={(e) => setFormData(prev => ({ ...prev, destinationPostalCode: e.target.value }))}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Shipment Details */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <Label>{t("Number of Pallets")}</Label>
                      <Input
                        type="number"
                        placeholder="ex: 4"
                        value={formData.pallets}
                        onChange={(e) => setFormData(prev => ({ ...prev, pallets: e.target.value }))}
                      />
                    </div>

                    <div>
                      <Label>{t("Total Weight")}</Label>
                      <div className="flex">
                        <Input
                          type="number"
                          placeholder="ex: 2500"
                          value={formData.weight}
                          onChange={(e) => setFormData(prev => ({ ...prev, weight: e.target.value }))}
                          className="rounded-r-none"
                        />
                        <Select value={formData.weightUnit} onValueChange={(value) => 
                          setFormData(prev => ({ ...prev, weightUnit: value }))
                        }>
                          <SelectTrigger className="w-20 rounded-l-none border-l-0">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="lb">lb</SelectItem>
                            <SelectItem value="kg">kg</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label>{t("Distance (km)")}</Label>
                      <Input
                        type="number"
                        placeholder="ex: 150"
                        value={formData.distance}
                        onChange={(e) => setFormData(prev => ({ ...prev, distance: e.target.value }))}
                      />
                    </div>
                  </div>

                  {/* Dimensions */}
                  <div>
                    <Label>{t("Dimensions")}</Label>
                    <div className="grid grid-cols-3 gap-3">
                      <Input
                        type="number"
                        placeholder={t("Length")}
                        value={formData.length}
                        onChange={(e) => setFormData(prev => ({ ...prev, length: e.target.value }))}
                      />
                      <Input
                        type="number"
                        placeholder={t("Width")}
                        value={formData.width}
                        onChange={(e) => setFormData(prev => ({ ...prev, width: e.target.value }))}
                      />
                      <Input
                        type="number"
                        placeholder={t("Height")}
                        value={formData.height}
                        onChange={(e) => setFormData(prev => ({ ...prev, height: e.target.value }))}
                      />
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      {t("In inches (for volume calculation)")}
                    </p>
                  </div>

                  {/* Calculate Button */}
                  <Button 
                    onClick={calculateQuote} 
                    className="w-full bg-transport-blue hover:bg-transport-blue/90"
                    size="lg"
                  >
                    <Calculator className="w-4 h-4 mr-2" />
                    {t("Calculate Quote")}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quote Results */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  {t("Quote Summary")}
                </h3>

                {quoteData ? (
                  <div className="space-y-4">
                    {/* Basic Info */}
                    <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                      <p>
                        {t("Issue Date:")} {quoteData.issueDate}
                      </p>
                      <p>
                        {t("Expiration Date:")} {quoteData.expiryDate}
                      </p>
                    </div>

                    <Separator />

                    {/* Cost Breakdown */}
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          {t("Base Cost (pallets):")}
                        </span>
                        <span className="text-sm font-medium text-gray-900 dark:text-white">
                          ${quoteData.baseCost.toFixed(2)}
                        </span>
                      </div>

                      {quoteData.weightSurcharge > 0 && (
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            {t("Weight Surcharge:")}
                          </span>
                          <span className="text-sm font-medium text-gray-900 dark:text-white">
                            ${quoteData.weightSurcharge.toFixed(2)}
                          </span>
                        </div>
                      )}

                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          {t("Fuel Surcharge:")}
                        </span>
                        <span className="text-sm font-medium text-gray-900 dark:text-white">
                          ${quoteData.fuelSurcharge.toFixed(2)}
                        </span>
                      </div>

                      <Separator />

                      <div className="flex justify-between">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          {t("Subtotal:")}
                        </span>
                        <span className="text-sm font-medium text-gray-900 dark:text-white">
                          ${quoteData.subtotal.toFixed(2)}
                        </span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          GST/TPS (5%):
                        </span>
                        <span className="text-sm text-gray-900 dark:text-white">
                          ${quoteData.gst.toFixed(2)}
                        </span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          QST/TVQ (9.975%):
                        </span>
                        <span className="text-sm text-gray-900 dark:text-white">
                          ${quoteData.qst.toFixed(2)}
                        </span>
                      </div>

                      <Separator />

                      <div className="flex justify-between">
                        <span className="text-lg font-semibold text-gray-900 dark:text-white">
                          {t("Total (Tax Inc.):")}
                        </span>
                        <span className="text-lg font-bold text-transport-blue">
                          ${quoteData.total.toFixed(2)}
                        </span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="pt-4 space-y-3">
                      <Button
                        onClick={handleGeneratePDF}
                        className="w-full bg-transport-purple hover:bg-transport-purple/90"
                      >
                        <FileText className="w-4 h-4 mr-2" />
                        {t("Generate PDF")}
                      </Button>

                      <Button
                        onClick={handlePrint}
                        variant="secondary"
                        className="w-full"
                      >
                        <Printer className="w-4 h-4 mr-2" />
                        {t("Print")}
                      </Button>

                      <Button
                        onClick={handleSaveQuote}
                        variant="outline"
                        className="w-full"
                        disabled={createQuoteMutation.isPending}
                      >
                        {createQuoteMutation.isPending ? "Saving..." : "Save Quote"}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Calculator className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500 dark:text-gray-400">
                      {t("Calculate a quote to see results")}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Quotes */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  {t("Recent Quotes")}
                </h3>
                <div className="space-y-3">
                  {recentQuotes.length > 0 ? (
                    recentQuotes.map((quote) => (
                      <div
                        key={quote.id}
                        className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg"
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="text-sm font-medium text-gray-900 dark:text-white">
                              {quote.company}
                            </p>
                            <p className="text-xs text-gray-600 dark:text-gray-400">
                              {new Date(quote.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <span className="text-sm font-medium text-transport-blue">
                            ${quote.total.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-4">
                      {t("No recent quotes")}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Contact Section */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-2 mb-4">
                  <Phone className="h-6 w-6 text-transport-blue" style={{ filter: 'drop-shadow(2px 2px 4px rgba(8, 132, 172, 0.3))' }} />
                  <h3 className="text-lg font-bold text-transport-blue">
                    {t("Questions?")}
                  </h3>
                </div>
                <div className="space-y-3">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                    {t("Contact Transport Morneau for more information")}
                  </p>
                  
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center space-x-3">
                      <Phone className="h-5 w-5 text-transport-blue" style={{ filter: 'drop-shadow(1px 1px 2px rgba(8, 132, 172, 0.3))' }} />
                      <a href="tel:1-844-884-2727" className="text-transport-blue hover:underline font-semibold">
                        1 844 884-2727
                      </a>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Globe className="h-5 w-5 text-transport-blue" style={{ filter: 'drop-shadow(1px 1px 2px rgba(8, 132, 172, 0.3))' }} />
                      <a 
                        href="https://www.groupemorneau.com" 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="text-transport-blue hover:underline font-semibold"
                      >
                        www.groupemorneau.com
                      </a>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Mail className="h-5 w-5 text-transport-blue" style={{ filter: 'drop-shadow(1px 1px 2px rgba(8, 132, 172, 0.3))' }} />
                      <a 
                        href="mailto:info@groupemorneau.com" 
                        className="text-transport-blue hover:underline font-semibold"
                      >
                        {t("Email Us")}
                      </a>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* PDF Preview Modal */}
      <Dialog open={showPDFPreview} onOpenChange={setShowPDFPreview}>
        <DialogContent className="max-w-4xl max-h-screen overflow-auto">
          <DialogHeader>
            <DialogTitle>{t("Quote Preview")}</DialogTitle>
          </DialogHeader>
          
          {quoteData && (
            <div>
              <div
                className="bg-white p-8 rounded-lg border-2 border-gray-200 text-black mb-6"
                dangerouslySetInnerHTML={{
                  __html: generatePDFContent(quoteData, language),
                }}
              />
              
              <div className="flex space-x-3">
                <Button
                  onClick={handleDownloadPDF}
                  className="flex-1 bg-transport-blue hover:bg-transport-blue/90"
                >
                  {t("Download PDF")}
                </Button>
                <Button
                  onClick={() => setShowPDFPreview(false)}
                  variant="secondary"
                  className="flex-1"
                >
                  {t("Close")}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
