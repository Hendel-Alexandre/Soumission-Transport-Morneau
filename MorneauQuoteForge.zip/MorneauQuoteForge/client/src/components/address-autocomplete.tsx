import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { MapPin } from "lucide-react";

interface AddressComponent {
  long_name: string;
  short_name: string;
  types: string[];
}

interface PlacePrediction {
  description: string;
  place_id: string;
  structured_formatting: {
    main_text: string;
    secondary_text: string;
  };
}

interface AddressAutocompleteProps {
  placeholder: string;
  value: string;
  onChange: (value: string) => void;
  onAddressSelect: (address: {
    street: string;
    city: string;
    province: string;
    postalCode: string;
    fullAddress: string;
  }) => void;
}

export function AddressAutocomplete({ 
  placeholder, 
  value, 
  onChange, 
  onAddressSelect 
}: AddressAutocompleteProps) {
  const [suggestions, setSuggestions] = useState<PlacePrediction[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout>();

  const searchAddresses = async (query: string) => {
    if (!query || query.length < 3) {
      setSuggestions([]);
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(`/api/places/autocomplete?input=${encodeURIComponent(query)}`);
      const data = await response.json();
      
      if (data.predictions) {
        setSuggestions(data.predictions);
        setIsOpen(true);
      } else if (data.message) {
        console.warn("Address autocomplete:", data.message);
      }
    } catch (error) {
      console.error("Error fetching address suggestions:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getPlaceDetails = async (placeId: string) => {
    try {
      const response = await fetch(`/api/places/details?place_id=${encodeURIComponent(placeId)}`);
      const data = await response.json();
      
      if (data.result) {
        parseAddressComponents(data.result.address_components, data.result.formatted_address);
      } else if (data.message) {
        console.warn("Place details error:", data.message);
      }
    } catch (error) {
      console.error("Error fetching place details:", error);
    }
  };

  const parseAddressComponents = (components: AddressComponent[], fullAddress: string) => {
    let street = "";
    let city = "";
    let province = "";
    let postalCode = "";

    components.forEach((component) => {
      const types = component.types;
      
      if (types.includes("street_number")) {
        street = component.long_name + " " + street;
      }
      if (types.includes("route")) {
        street += component.long_name;
      }
      if (types.includes("locality") || types.includes("administrative_area_level_3")) {
        city = component.long_name;
      }
      if (types.includes("administrative_area_level_1")) {
        province = component.short_name;
      }
      if (types.includes("postal_code")) {
        postalCode = component.long_name;
      }
    });

    onAddressSelect({
      street: street.trim(),
      city,
      province,
      postalCode,
      fullAddress
    });
  };

  const handleInputChange = (newValue: string) => {
    onChange(newValue);
    
    // Clear existing timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    // Set new timeout for debounced search
    timeoutRef.current = setTimeout(() => {
      searchAddresses(newValue);
    }, 300);
  };

  const handleSuggestionSelect = (prediction: PlacePrediction) => {
    onChange(prediction.description);
    setIsOpen(false);
    setSuggestions([]);
    getPlaceDetails(prediction.place_id);
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return (
    <div className="relative">
      <Input
        placeholder={placeholder}
        value={value}
        onChange={(e) => handleInputChange(e.target.value)}
        onFocus={() => {
          if (suggestions.length > 0) {
            setIsOpen(true);
          }
        }}
        onBlur={() => {
          // Delay closing to allow for suggestion selection
          setTimeout(() => setIsOpen(false), 150);
        }}
        autoComplete="off"
      />
      {isLoading && (
        <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-transport-blue"></div>
        </div>
      )}
      
      {isOpen && suggestions.length > 0 && (
        <div className="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg max-h-60 overflow-auto">
          {suggestions.map((prediction) => (
            <div
              key={prediction.place_id}
              className="flex items-start gap-2 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer border-b border-gray-100 dark:border-gray-600 last:border-b-0"
              onMouseDown={(e) => {
                e.preventDefault(); // Prevent input blur
                handleSuggestionSelect(prediction);
              }}
            >
              <MapPin className="h-4 w-4 mt-0.5 text-gray-400 flex-shrink-0" />
              <div className="flex flex-col">
                <span className="font-medium text-gray-900 dark:text-white">
                  {prediction.structured_formatting.main_text}
                </span>
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {prediction.structured_formatting.secondary_text}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}