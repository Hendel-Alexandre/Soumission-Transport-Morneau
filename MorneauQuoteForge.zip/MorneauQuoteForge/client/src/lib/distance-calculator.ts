import { apiRequest } from "./queryClient";

export interface DistanceResult {
  distance: number;
  unit: string;
}

export async function calculateDistance(origin: string, destination: string): Promise<DistanceResult> {
  try {
    const response = await apiRequest('POST', '/api/distance', {
      origin,
      destination
    });
    
    return await response.json();
  } catch (error) {
    console.error('Failed to calculate distance:', error);
    // Return default distance if API fails
    return { distance: 100, unit: 'km' };
  }
}

// Helper function to format address for API
export function formatAddress(street: string, city: string): string {
  return `${street}, ${city}`.trim();
}
