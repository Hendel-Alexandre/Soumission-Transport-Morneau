export interface QuoteData {
  quoteNumber: string;
  company: string;
  originAddress: string;
  destinationAddress: string;
  pallets: number;
  weight: number;
  weightUnit: string;
  distance: number;
  fuelType: string;
  baseCost: number;
  weightSurcharge: number;
  fuelSurcharge: number;
  subtotal: number;
  gst: number;
  qst: number;
  total: number;
  issueDate: string;
  expiryDate: string;
  dimensions?: {
    length: string;
    width: string;
    height: string;
  };
}

export function generatePDFContent(quoteData: QuoteData, language: 'fr' | 'en'): string {
  // Calculate cubic feet if dimensions are provided
  let cubicFeet = '';
  let dimensionsDisplay = '';
  
  if (quoteData.dimensions && quoteData.dimensions.length && quoteData.dimensions.width && quoteData.dimensions.height) {
    const l = parseFloat(quoteData.dimensions.length) || 0;
    const w = parseFloat(quoteData.dimensions.width) || 0;
    const h = parseFloat(quoteData.dimensions.height) || 0;
    if (l > 0 && w > 0 && h > 0) {
      // Convert inches to feet and calculate cubic feet
      cubicFeet = ((l * w * h) / 1728).toFixed(0);
      dimensionsDisplay = `${quoteData.dimensions.length}X${quoteData.dimensions.width}X${quoteData.dimensions.height}`;
    }
  }

  // Format dates
  const effectiveDate = new Date(quoteData.issueDate).toLocaleDateString('en-CA');
  const expiryDate = new Date(quoteData.expiryDate).toLocaleDateString('en-CA');
  
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Transport Morneau Quote</title>
  <style>
    body { 
      font-family: Arial, sans-serif; 
      margin: 0; 
      padding: 20px; 
      color: #000; 
      background: white; 
      font-size: 11px; 
      line-height: 1.2;
    }
    table { 
      width: 100%; 
      border-collapse: collapse; 
    }
    .header-table td { 
      padding: 10px; 
      vertical-align: top; 
    }
    .center { 
      text-align: center; 
    }
    .right { 
      text-align: right; 
    }
    .bold { 
      font-weight: bold; 
    }
    .small { 
      font-size: 10px; 
    }
    .tiny { 
      font-size: 8px; 
    }
    .bordered { 
      border: 1px solid #000; 
    }
    .details-table { 
      border: 1px solid #000; 
      font-size: 10px; 
    }
    .details-table th, .details-table td { 
      border: 1px solid #000; 
      padding: 5px; 
    }
    .details-table th { 
      background-color: #f0f0f0; 
      text-align: center; 
    }
    .page-break { 
      page-break-after: always; 
    }
    .legal-text { 
      font-size: 8px; 
      line-height: 1.3; 
      text-align: justify; 
      margin: 20px 0; 
    }
    .contact-box { 
      border: 1px solid #000; 
      padding: 8px; 
      margin-left: 20px; 
      font-size: 9px; 
    }
  </style>
</head>
<body>
  <!-- Page 1 -->
  <div class="page-break">
    <!-- Header -->
    <table class="header-table">
      <tr>
        <td class="center" style="width: 33%;">
          <div class="small">
            <div class="bold">40 RUE PRINCIPALE</div>
            <div class="bold">SAINT ARSENE</div>
            <div class="bold">QUEBEC G0L 2K0</div>
            <div class="bold">418 862-2727</div>
          </div>
        </td>
        <td class="center" style="width: 34%;">
          <h1 style="margin: 0; font-size: 16px; font-weight: bold;">
            SOUMISSION / QUOTE
          </h1>
        </td>
        <td style="width: 33%;"></td>
      </tr>
    </table>

    <!-- Three Column Section -->
    <table style="margin-bottom: 15px;">
      <tr>
        <td class="small" style="width: 33%; vertical-align: top; padding-right: 10px;">
          <div class="bold" style="margin-bottom: 5px;">APPELLANT / CALLER</div>
          <div style="line-height: 1.3; height: 60px;">
            ${quoteData.company.toUpperCase()}<br>
            ${quoteData.originAddress.split(',')[0] || ''}<br>
            ${quoteData.originAddress.split(',').slice(1).join(',').trim() || ''}
          </div>
        </td>
        <td class="small" style="width: 34%; vertical-align: top; padding: 0 5px;">
          <div class="bold" style="margin-bottom: 5px;">SHIPPER / EXPEDITEUR</div>
          <div style="line-height: 1.3; height: 60px;">
            ${quoteData.company.toUpperCase()}<br>
            ${quoteData.originAddress.split(',')[0] || ''}<br>
            ${quoteData.originAddress.split(',').slice(1).join(',').trim() || ''}
          </div>
        </td>
        <td class="small" style="width: 33%; vertical-align: top; padding-left: 10px;">
          <div class="bold" style="margin-bottom: 5px;">CONSIGNEE / CONSIGNATAIRE</div>
          <div style="line-height: 1.3; height: 60px;">
            ${quoteData.destinationAddress.split(',')[0] || ''}<br>
            ${quoteData.destinationAddress.split(',').slice(1).join(',').trim() || ''}
          </div>
        </td>
      </tr>
      <tr>
        <td colspan="3" class="center small" style="padding: 10px 0;">
          <strong>QC</strong>
        </td>
      </tr>
    </table>

    <!-- Date and Contact Section -->
    <table style="margin-bottom: 15px;">
      <tr>
        <td class="small" style="width: 50%; vertical-align: top;">
          <div style="margin-bottom: 5px;"><strong>Date d'entrée en vigueur/Effective Date:</strong> ${effectiveDate}</div>
          <div style="margin-bottom: 15px;"></div>
          <div style="margin-bottom: 5px;"><strong>Date d'expiration/Expiry Date:</strong> ${expiryDate}</div>
          <div style="margin-bottom: 15px;"></div>
          <div><strong>TERME DE PAIEMENT / PAYMENT TERM</strong></div>
        </td>
        <td class="center" style="width: 50%; vertical-align: top;">
          <div class="contact-box">
            <div class="bold">*** Pour des demandes de taux S.V.P. utilisez l'adresse suivante -</div>
            <div class="bold">For rate request please use the following address</div>
            <div class="bold">taux@groupemorneau.com ou/or rates@groupemorneau.com ***</div>
            <div class="bold">VISITEZ NOUS / VISIT US : www.groupemorneau.com</div>
          </div>
        </td>
      </tr>
    </table>

    <!-- Legal Disclaimer -->
    <div class="legal-text">
      <p style="margin-bottom: 10px;">
        Le client reconnaît que lorsqu'il retiendra les services de Morneau Geo, même en l'absence de connaissement en bonne et due forme et nonobstant l'émission de tout autre document d'expédition ou de transport, tous les mouvements de transport effectués par Morneau Geo seront assujettis aux stipulations minimales prévues à l'Annexe 2 du Règlement sur les exigences applicables aux connaissements (décret 1198-99, 20 octobre 1999 et amendements subséquents). Le montant dont Morneau Geo pourrait être redevable pour toute perte ou dommage ne saurait excéder le prix coûtant de la marchandise expédiée jusqu'à concurrence de 2.00 $/lb (4.41$/kg).
      </p>
      <p style="margin-bottom: 10px;">
        Les prix de cette soumission ne sont valables que si les biens remis en transport correspondent au type de marchandise mentionné lors de la soumission tel que poids, quantité, dimensions, fragilité, matières dangereuses ou non, etc. et aux destinations et modalités de livraisons requises lors de la demande de soumission. Toute divergence avec les informations de la soumission pourrait entrainer un ajustement tarifaire.
      </p>
      <p style="margin-bottom: 15px;">
        Le fait de remettre des biens en transport suite à la réception de cette soumission équivaut à l'acceptation par le client des termes et conditions qui y apparaissent.
      </p>
      
      <p style="margin-bottom: 10px;">
        When retaining the services of Morneau Geo, the client recognizes that even in the absence of a bill of lading completed in due form and notwithstanding the release of any other shipment or transport document, all carriage performed by Morneau Geo will be subject to minimum stipulations included in Annex 2 of Regulation respecting the requirements for bills of lading (decree 1198-99, October 20th, 1999 and subsequent amendments). The amount for which Morneau Geo may be liable in case of loss or damage shall not exceed the cost price of the goods shipped and is limited to a maximum of $2.00 per pound ($4.41 per kilogram).
      </p>
      <p style="margin-bottom: 10px;">
        The prices of this quote are only valid if the goods handed over for carriage correspond to the type of merchandise mentioned during the tender, such as the weight, quantity, dimensions, fragility, hazardous materials or not, etc., and to the delivery destinations and modalities required throughout the tender request. Any divergence with the tender's information could lead to an adjustment of the price.
      </p>
      <p>
        Entrusting goods to Morneau Transport for carriage following the reception of this tender means the client accepts the terms and conditions specified in this document.
      </p>
    </div>

    <!-- Bill To Section -->
    <table style="margin: 20px 0;">
      <tr>
        <td class="small">
          <div class="bold">FACTURÉ À / BILL TO</div>
          <div class="bold"># CODE: ${quoteData.quoteNumber}</div>
          <div style="margin-top: 10px; line-height: 1.3;">
            ${quoteData.company.toUpperCase()}<br>
            ${quoteData.originAddress}
          </div>
        </td>
      </tr>
    </table>

    <div class="right tiny" style="margin: 10px 0;">Page 1 of 2</div>
  </div>

  <!-- Page 2 -->
  <div>
    <!-- Header -->
    <table class="header-table">
      <tr>
        <td class="center" style="width: 33%;">
          <div class="small">
            <div class="bold">40 RUE PRINCIPALE</div>
            <div class="bold">SAINT ARSENE</div>
            <div class="bold">QUEBEC G0L 2K0</div>
            <div class="bold">418 862-2727</div>
          </div>
        </td>
        <td class="center" style="width: 34%;">
          <h1 style="margin: 0; font-size: 16px; font-weight: bold;">
            SOUMISSION / QUOTE
          </h1>
        </td>
        <td class="right" style="width: 33%;">
          <div class="bold" style="font-size: 12px;">
            *${quoteData.quoteNumber}*
          </div>
        </td>
      </tr>
    </table>

    <!-- Three Column Section with Data -->
    <table style="margin-bottom: 15px;">
      <tr>
        <td class="small" style="width: 33%; vertical-align: top; padding-right: 10px;">
          <div class="bold" style="margin-bottom: 5px;">APPELLANT / CALLER</div>
          <div style="line-height: 1.3;">
            ${quoteData.company.toUpperCase()}<br>
            ${quoteData.originAddress.split(',')[0] || ''}<br>
            ${quoteData.originAddress.split(',').slice(1).join(',').trim() || ''}
          </div>
        </td>
        <td class="small" style="width: 34%; vertical-align: top; padding: 0 5px;">
          <div class="bold" style="margin-bottom: 5px;">SHIPPER / EXPEDITEUR</div>
          <div style="line-height: 1.3;">
            ${quoteData.company.toUpperCase()}<br>
            ${quoteData.originAddress.split(',')[0] || ''}<br>
            ${quoteData.originAddress.split(',').slice(1).join(',').trim() || ''}
          </div>
        </td>
        <td class="small" style="width: 33%; vertical-align: top; padding-left: 10px;">
          <div class="bold" style="margin-bottom: 5px;">CONSIGNEE / CONSIGNATAIRE</div>
          <div style="line-height: 1.3;">
            ${quoteData.destinationAddress.split(',')[0] || ''}<br>
            ${quoteData.destinationAddress.split(',').slice(1).join(',').trim() || ''}
          </div>
        </td>
      </tr>
      <tr>
        <td colspan="3" class="center small" style="padding: 10px 0;">
          <strong>QC</strong>
        </td>
      </tr>
    </table>

    <!-- Date and Contact Section with Data -->
    <table style="margin-bottom: 15px;">
      <tr>
        <td class="small" style="width: 50%; vertical-align: top;">
          <div style="margin-bottom: 5px;"><strong>Date d'entrée en vigueur/Effective Date:</strong> ${effectiveDate}</div>
          <div style="margin-bottom: 15px;"></div>
          <div style="margin-bottom: 5px;"><strong>Date d'expiration/Expiry Date:</strong> ${expiryDate}</div>
          <div style="margin-bottom: 15px;"></div>
          <div><strong>TERME DE PAIEMENT / PAYMENT TERM</strong></div>
        </td>
        <td class="center" style="width: 50%; vertical-align: top;">
          <div class="contact-box">
            <div class="bold">*** Pour des demandes de taux S.V.P. utilisez l'adresse suivante -</div>
            <div class="bold">For rate request please use the following address</div>
            <div class="bold">taux@groupemorneau.com ou/or rates@groupemorneau.com ***</div>
            <div class="bold">VISITEZ NOUS / VISIT US : www.groupemorneau.com</div>
          </div>
        </td>
      </tr>
    </table>

    <!-- Details Table -->
    <table class="details-table" style="margin-bottom: 15px;">
      <thead>
        <tr>
          <th style="width: 8%;">QTÉ/QTY</th>
          <th style="width: 35%;">DESCRIPTION</th>
          <th style="width: 12%;">POIDS/<br>WEIGHT</th>
          <th style="width: 12%;">POIDS<br>CUBÉ/<br>AS</th>
          <th style="width: 10%;">COMME/<br>AS</th>
          <th style="width: 10%;">TAUX/<br>RATE</th>
          <th style="width: 13%;">CHARGES</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="center">${quoteData.pallets} PAL</td>
          <td>DESC${dimensionsDisplay ? '<br>' + dimensionsDisplay : ''}</td>
          <td class="center">${quoteData.weight.toFixed(0)} ${quoteData.weightUnit.toUpperCase()}</td>
          <td></td>
          <td></td>
          <td class="right">$${(quoteData.baseCost / quoteData.pallets).toFixed(2)}</td>
          <td class="right">$${quoteData.baseCost.toFixed(2)}</td>
        </tr>
        ${quoteData.weightSurcharge > 0 ? `
        <tr>
          <td></td>
          <td>POIDS EXEDENTAIRE PAL / EXCESS WEIGH PAL</td>
          <td></td>
          <td></td>
          <td></td>
          <td class="right">$${(quoteData.weightSurcharge / quoteData.pallets).toFixed(2)}</td>
          <td class="right">$${quoteData.weightSurcharge.toFixed(2)}</td>
        </tr>
        ` : ''}
        <tr>
          <td></td>
          <td>SURC. CARB./FUEL SURC.</td>
          <td></td>
          <td></td>
          <td></td>
          <td class="right">${quoteData.fuelType.toUpperCase()} ${((quoteData.fuelSurcharge / quoteData.baseCost) * 100).toFixed(1)}%</td>
          <td class="right">$${quoteData.fuelSurcharge.toFixed(2)}</td>
        </tr>
        <tr>
          <td></td>
          <td>${dimensionsDisplay ? 'PCS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LxWxH' : ''}</td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td style="padding: 15px;"></td>
          <td style="padding: 15px;"><strong>Total Pieds Cubes / cubic feet: ${cubicFeet}</strong></td>
          <td style="padding: 15px;"></td>
          <td style="padding: 15px;"></td>
          <td style="padding: 15px;"></td>
          <td style="padding: 15px;"></td>
          <td style="padding: 15px;"></td>
        </tr>
      </tbody>
    </table>

    <!-- Bill To and Totals Section -->
    <table style="margin-bottom: 15px;">
      <tr>
        <td class="small" style="width: 60%; vertical-align: top;">
          <div class="bold">FACTURÉ À / BILL TO</div>
          <div class="bold"># CODE: ${quoteData.quoteNumber}</div>
          <div style="margin-top: 10px; line-height: 1.3;">
            ${quoteData.company.toUpperCase()}<br>
            ${quoteData.originAddress}
          </div>
        </td>
        <td class="small" style="width: 40%; vertical-align: top;">
          <table style="width: 100%;">
            <tr>
              <td style="padding: 3px 0; border-bottom: 1px solid #ccc;" class="bold">SOUS-TOTAL / SUB-TOTAL:</td>
              <td style="padding: 3px 0; border-bottom: 1px solid #ccc;" class="right bold">$${quoteData.subtotal.toFixed(2)}</td>
            </tr>
            <tr>
              <td style="padding: 3px 0; border-bottom: 1px solid #ccc;">TPS/GST:</td>
              <td style="padding: 3px 0; border-bottom: 1px solid #ccc;" class="right">$${quoteData.gst.toFixed(2)}</td>
            </tr>
            <tr>
              <td style="padding: 3px 0; border-bottom: 1px solid #ccc;">
                # 105363139<br><br>
                TVQ/PST:
              </td>
              <td style="padding: 3px 0; border-bottom: 1px solid #ccc;" class="right">
                <br><br>
                $${quoteData.qst.toFixed(2)}
              </td>
            </tr>
            <tr>
              <td style="padding: 3px 0;">
                # 1000682272TQ0003<br><br>
                <span class="bold">TOTAL:</span>
              </td>
              <td style="padding: 3px 0;" class="right">
                <br><br>
                <span class="bold">$${quoteData.total.toFixed(2)}</span>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>

    <div class="right tiny" style="margin: 10px 0;">Page 2 of 2</div>
  </div>
</body>
</html>`;
}

export async function downloadPDF(quoteData: QuoteData, language: 'fr' | 'en') {
  try {
    const content = generatePDFContent(quoteData, language);
    
    // Create a blob with the HTML content
    const blob = new Blob([content], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    
    // Create download link
    const link = document.createElement('a');
    link.href = url;
    link.download = `soumission_${quoteData.company.replace(/[^a-zA-Z0-9]/g, '_')}_${new Date().toISOString().split('T')[0]}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Clean up
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw error;
  }
}